
RivaBot/
├── build
│   ├── index.js
│   └── src/
│       ├── abstract/
│       │   ├── RivaCommand.js
│       │   ├── RivaEvent.js
│       │   ├── RivaPlayer.js
│       │   └── RivaTrack.js
│       │
│       ├── commands/
│       │   ├── Developer/
│       │   │		├── AddPremium.js
│       │   │		├── Management.js
│       │   │		├── Noprefix.js
│       │   │		├── RemovePremium.js
│       │   │		├── Trusted.js
│       │   │		└── UpdatePremium.js
│       │   │
│       │   ├── Filters/
│       │   │		├── 8d.js
│       │   │		├── Bassboost.js
│       │   │		├── China.js
│       │   │		├── Chipmunk.js
│       │   │		├── ClearFilters.js
│       │   │		├── Earrape.js
│       │   │		├── Nightcore.js
│       │   │		├── Treblebass.js
│       │   │		├── Tremelo.js
│       │   │		├── Vaporwave.js
│       │   │		└── Vibrato.js
│       │   │
│       │   ├── Information/
│       │   │		├── About.js
│       │   │		├── Invite.js
│       │   │		├── Latency.js
│       │   │		├── Stats.js
│       │   │		├── Support.js
│       │   │		└── Vote.js
│       │   │
│       │   ├── Integration/-
│       │   ├── Music/
│       │   │		├── ClearQueue.js
│       │   │		├── Connect.js
│       │   │		├── Disconnect.js
│       │   │		├── Loop.js
│       │   │		├── Move.js
│       │   │		├── NowPlaying.js
│       │   │		├── Pause.js
│       │   │		├── Play.js
│       │   │		├── Previous.js
│       │   │		├── Queue.js
│       │   │		├── Remove.js
│       │   │		├── Replay.js
│       │   │		├── Resume.js
│       │   │		├── Shuffle.js
│       │   │		├── Skip.js
│       │   │		├── Stop.js
│       │   │		└── Volume.js
│       │   │
│       │   └── Utility
│       │			 └
│       ├── dashboard/
│       │   ├── src/
│       │   │		├── ai/
│       │   │		│	 ├── dev.ts
│       │   │		│	 └── genkit.ts
│       │   │		│
│       │   │		├── app/
│       │   │		│	 ├── app/
│       │   │		│	 │      ├── dashboard
│       │   │		│	 │      │           ├── [serverid]/
│       │   │		│	 │      │           │			├── music/ page.tsx
│       │   │		│	 │      │           │			└── page.tsx
│       │   │		│	 │      │           └── page.tsx
│       │   │		│	 │      ├── nodes/ page.tsx
│       │   │		│	 │      ├── status/ page.tsx
│       │   │		│	 │      └── layout.tsx
│       │   │		│	 │
│       │   │		│	 ├── global.css
│       │   │		│	 ├── layout.tsx
│       │   │		│	 └── page.tsx
│       │   │		│
│       │   │		├── components/
│       │   │		│	 ├── ui/... too many to write down manually
│       │   │		│	 └── icons.tsx
│       │   │		│
│       │   │		├── hooks/
│       │   │		│	 ├── use-mobile.tsx
│       │   │		│	 └── use-toast.ts
│       │   │		│
│       │   │		└── lib/ 
│       │   │		  	  ├── mock-data.ts
│       │   │		 	  ├── placeholder-images.json
│       │   │		 	  ├── placeholder-images.ts
│       │   │		 	  ├── types.ts
│       │   │		 	  └── utils.ts
│       │   │
│       │   ├── components.json
│       │   ├── index.js
│       │   ├── next-env.d.ts
│       │   ├── next.config.ts
│       │   ├── postcss.config.mjs
│       │   ├── tailwind.config.ts
│       │   ├── package.json
│       │   └── package-lock.json
│       │
│       ├── database/
│       │   ├── db.js
│       │   ├── dj.sqlite
│       │   ├── embeds.sqlite
│       │   ├── management.sqlite
│       │   ├── prefix.sqlite
│       │   ├── premium.sqlite
│       │   └── settings.sqlite
│       │
│       ├── events/
│       │   ├── Afk.js
│       │   ├── GuildCreate.js
│       │   ├── GuildDelete.js
│       │   ├── GuildMember.js
│       │   ├── InteractionCreate.js
│       │   ├── MessageCreate.js
│       │   ├── Ready.js
│       │   ├── Setup.js
│       │   └── VoiceState.js
│       │
│       ├── setting/
│       │   ├── Config.js
│       │   └── Emoji.js
│       │
│       ├── structures/
│       │   ├── Client.js
│       │   ├── Commands.js
│       │   ├── Events.js
│       │   ├── Logger.js
│       │   └── Utils.js
│       │
│       ├── wrapper/
│       │   ├── db/
│       │   │		├── dj.js
│       │   │		├── embeds.js
│       │   │		├── management.js
│       │   │		├── prefix.js
│       │   │		├── premium.js
│       │   │		└── settings.js
│       │   ├── Dispatcher.js
│       │   ├── Kazagumo.js
│       │   ├── Shoukaku.js
│       │   ├── Reconnection.js
│       │   ├── Spotify.js
│       │   ├── NodeRouter.js
│       │   └── Wrapper.js
│       │
│       └── riva.js
├── node_modules/... too many package names ;-; shitty ass
├── .env
├── index.js
├── package.json
├── package-lock.json
├── tsconfig.json
└── STRUCTURE.md
